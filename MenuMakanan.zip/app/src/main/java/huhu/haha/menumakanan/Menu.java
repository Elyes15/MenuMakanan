package huhu.haha.menumakanan;

import android.content.Intent;

public class Menu {

    private String nama, harga, desc;
    private int id_gambar;

    public Menu(String nama, String harga, String desc, int id_gambar) {
        this.nama = nama;
        this.harga = harga;
        this.desc = desc;
        this.id_gambar = id_gambar;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getHarga() {
        return harga;
    }

    public void setHarga(String harga) {
        this.harga = harga;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public int getId_gambar() {
        return id_gambar;
    }

    public void setId_gambar(int id_gambar) {
        this.id_gambar = id_gambar;
    }
}
