package huhu.haha.menumakanan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recMenu;
    private ArrayList<Menu> listMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recMenu = findViewById(R.id.rec_menu);
        initData();

        recMenu.setAdapter(new MenuAdapter(listMenu));
        recMenu.setLayoutManager(new LinearLayoutManager(this));
    }

    private void initData(){
        this.listMenu = new ArrayList<>();
        listMenu.add(new Menu("Nasi Goreng",
                "Rp. 10.000",
                "Nasi goreng ayam dengan tambahan telur dan kerupuk",
                R.drawable.nasigoreng));

        listMenu.add(new Menu("Ayam Bakar",
                "Rp. 10.000",
                "Ayam yang dibumbui dengan kunyit, bawang putih, bawang merah dan rempah-rempah lainnya. " +
                        "Dipanggang di atas arang.",
                R.drawable.ayambakar));


        listMenu.add(new Menu("Ayam Goreng",
                "Rp. 10.000",
                "Ayam digoreng hidangan yang dibuat dari potongan daging ayam yang telah dilapisi dengan tepung atau adonan encer yang dibumbui dan digoreng.",
                R.drawable.ayamgoreng));

        listMenu.add(new Menu("Bakso",
                "Rp. 10.000",
                "Bakso adalah campuran daging giling dan tepung tapioka yang dibentuk menyerupai bulat.",
                R.drawable.bakso));

        listMenu.add(new Menu("Mie Ayam",
                "Rp. 10.000",
                "Mie ayam hidangan Indonesia yang terbuat dari mie gandum kuning yang dibumbui dengan daging ayam yang biasanya dipotong dadu.",
                R.drawable.mieayam));

        listMenu.add(new Menu("Seblak",
                "Rp. 10.000",
                "Sebalk terbuat dari krupuk basah dimasak dengan telur orak-arik, sayuran, dan sumber protein lainnya (ayam, ceker ayam, makanan laut, atau sosis sapi), dengan saus pedas termasuk bawang putih, bawang merah, kencur , kecap manis, dan sambal.",
                R.drawable.seblak));

        listMenu.add(new Menu("Kebab",
                "Rp. 10.000",
                "Kebab panganan cepat saji terdiri atas daging sapi yang dipanggang seperti sate kemudian diiris-iris ditambah dengan sayuran segar dan mayones, lalu dibalut dengan kulit tortila.",
                R.drawable.kebab));

        listMenu.add(new Menu("Burger",
                "Rp. 10.000",
                "Burger berupa roti berbentuk bundar yang diiris dua dan di tengahnya diisi dengan patty yang biasanya diambil dari daging, " +
                        "kemudian sayur-sayuran berupa selada, tomat dan bawang bombai. Sebagai sausnya, burger diberi berbagai jenis saus seperti mayones, saus tomat " +
                        "dan sambal serta mustard. Beberapa varian burger juga dilengkapi dengan keju, asinan, serta bahan pelengkap lain seperti sosis",
                R.drawable.burger));

        listMenu.add(new Menu("Pizza",
                "Rp. 10.000",
                "Pizza hidangan gurih dari Italia berupa adonan bundar dan pipih, yang dipanggang di oven dan dilumuri saus tomat serta keju dengan " +
                        "bahan makanan tambahan lainnya yang bisa dipilih. Keju yang dipakai mozzarella atau keju pizza, bisa juga keju parmesan dan beberapa " +
                        "keju lainnya.",
                R.drawable.pizza));

        listMenu.add(new Menu("Ramen",
                "Rp. 10.000",
                "Ramen berbahan dasar mie dengan perpaduannya kuah berupa miso, toripaitan, shoyu, ataupun shio.",
                R.drawable.ramen));
    }
}