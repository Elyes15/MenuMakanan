package huhu.haha.menumakanan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class DetailActivity extends AppCompatActivity {

    ImageView imgGambarMakanan;
    TextView txtNamaMakanan, txtDescMakanan, txtHargaMakanan;

    String name = "nama";
    String gambar = "img";
    String descrip = "desc";
    String price = "harga";

    String namanya;
    int gambare;
    String descripe;
    String hargane;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        txtNamaMakanan = findViewById(R.id.nama_makanan);
        txtDescMakanan = findViewById(R.id.desc_makanan);
        imgGambarMakanan = findViewById(R.id.gambar_makanan);
        txtHargaMakanan = findViewById(R.id.harga_makanan);

        Bundle bundle = getIntent().getExtras();
        namanya = bundle.getString(name);
        descripe = bundle.getString(descrip);
        hargane = bundle.getString(price);
        gambare = bundle.getInt(gambar);

        txtNamaMakanan.setText(namanya);
        txtDescMakanan.setText(descripe);
        txtHargaMakanan.setText(hargane);
        imgGambarMakanan.setImageResource(Integer.parseInt(String.valueOf(gambare)));
    }
}