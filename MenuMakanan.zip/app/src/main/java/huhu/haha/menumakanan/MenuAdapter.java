package huhu.haha.menumakanan;

import android.content.Context;
import android.content.Intent;
import android.database.DatabaseErrorHandler;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.view.menu.MenuView;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MenuAdapter extends RecyclerView.Adapter<MenuAdapter.ViewHolder> {

    public MenuAdapter(ArrayList<Menu> listMenu) {
        this.listMenu = listMenu;
    }

    private ArrayList<Menu> listMenu;

    @NonNull
    @Override
    public MenuAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        ViewHolder holder = new ViewHolder(inflater.inflate(R.layout.list_menu, parent, false));

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MenuAdapter.ViewHolder holder, int position) {
        Menu menu = listMenu.get(position);
        holder.txtNama.setText(menu.getNama());
        holder.txtHarga.setText(menu.getHarga());
        holder.imgMakanan.setImageResource(menu.getId_gambar());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String namaMakanan = menu.getNama();
                int imgMenu = menu.getId_gambar();
                String descMakanan = menu.getDesc();
                String hargaMakanan = menu.getHarga();

                Intent intent = new Intent(holder.itemView.getContext(), DetailActivity.class);
                intent.putExtra("nama",namaMakanan);
                intent.putExtra("img",imgMenu);
                intent.putExtra("desc",descMakanan);
                intent.putExtra("harga",hargaMakanan);
                holder.itemView.getContext().startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return listMenu.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView txtNama, txtHarga;
        public ImageView imgMakanan;
        public CardView itemView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            txtNama = (TextView) itemView.findViewById(R.id.txt_namaMakanan);
            txtHarga = (TextView) itemView.findViewById(R.id.txt_harga);
            imgMakanan = (ImageView) itemView.findViewById(R.id.img_makanan);
            this.itemView = (CardView) itemView.findViewById(R.id.cardView_makanan);
        }
    }
}
